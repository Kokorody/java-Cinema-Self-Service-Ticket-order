/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinema;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class Cinema extends JFrame {
    private final String[] MOVIE_SCHEDULES = {"10:00 WIB", "15:00 WIB", "20:00 WIB"};
    private final String[] MOVIE = {"Film A", "Film B", "Film C"};
    private final String[] DAYS = {"08/04/2024 (Sunday)", "09/04/2024 (Monday)", "10/04/2024 (Tuesday)", 
    "11/04/2024 (Wednesday)", "12/04/2024 (Thursday)", "13/04/2024 (Friday)", "14/04/2024 (Saturday)"};
    private final int TOTAL_SEATS = 50; // Total kursi
    private final int TICKET_PRICE = 40000; // harga

    // jgn diotak atik, sensitive!
    // Komponen GUI
    private JPanel moviePanel;
    private JComboBox<String> movieComboBox;
    private JComboBox<String> scheduleComboBox;
    private JComboBox<String> dayComboBox;
    private JButton selectSeatsButton;

    private JPanel seatPanel;
    private List<Integer> selectedSeats;
    private JButton continueButton;

    private JPanel paymentPanel;
    private JLabel totalLabel;
    private JButton payButton;
    private JComboBox<String> paymentOptionComboBox;
    // Map untuk nyimpenn kursi yang udah diisi atau dibeli
    private Map<String, Map<String, Map<String, List<Integer>>>> occupiedSeatsMap;
    private Map<String, Map<String, Map<String, List<Integer>>>> purchasedSeatsMap;
    private int bookingIdCounter = 1;

    // structure layout / Konstruktor
    public Cinema() {
        setTitle("Ticket Booking System");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        occupiedSeatsMap = new HashMap<>();
        purchasedSeatsMap = new HashMap<>();

        initializeMoviePanel();
        initializePaymentPanel();

        setLayout(new CardLayout());
        add(moviePanel, "MoviePanel");
        add(paymentPanel, "PaymentPanel");

        showMoviePanel();
    }

    // main menu 
    private void initializeMoviePanel() {
        moviePanel = new JPanel();
        moviePanel.setLayout(new GridLayout(6, 1));

        movieComboBox = new JComboBox<>(MOVIE);
        scheduleComboBox = new JComboBox<>(MOVIE_SCHEDULES);
        dayComboBox = new JComboBox<>(DAYS);
        selectSeatsButton = new JButton("Select Seats");

        moviePanel.add(new JLabel("movie name:"));
        moviePanel.add(movieComboBox);
        moviePanel.add(new JLabel("Select Schedule:"));
        moviePanel.add(scheduleComboBox);
        moviePanel.add(new JLabel("Select Date:"));
        moviePanel.add(dayComboBox);
        moviePanel.add(selectSeatsButton);

        selectSeatsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                initializeSeatPanel();
                showSeatPanel();
            }
        });
    }

    // pemilihan kursi
    private void initializeSeatPanel() {
        seatPanel = new JPanel();
        seatPanel.setLayout(new BorderLayout());

        JPanel seatSelectionPanel = new JPanel(new GridLayout(5, 10));
        selectedSeats = new ArrayList<>();

        String movie = (String) movieComboBox.getSelectedItem();
        String schedule = (String) scheduleComboBox.getSelectedItem();
        String day = (String) dayComboBox.getSelectedItem();
        // meriksa apakah kursi udah diisi pada film, jadwal, dan tanggal tertentu
        if (!occupiedSeatsMap.containsKey(movie)) {
            occupiedSeatsMap.put(movie, new HashMap<>());
        }
        if (!occupiedSeatsMap.get(movie).containsKey(schedule)) {
            occupiedSeatsMap.get(movie).put(schedule, new HashMap<>());
        }
        if (!occupiedSeatsMap.get(movie).get(schedule).containsKey(day)) {
            occupiedSeatsMap.get(movie).get(schedule).put(day, generateOccupiedSeats());
        }
        // ngisi panel kursi berdasarkan status kursi
        for (int i = 0; i < TOTAL_SEATS; i++) {
            JButton seatButton = new JButton(String.valueOf(i + 1));
            seatButton.setEnabled(false);
            if (occupiedSeatsMap.get(movie).get(schedule).get(day).contains(i + 1)) {
                seatButton.setBackground(Color.RED); // Kursi udah diisi
            } else if (purchasedSeatsMap.containsKey(movie) && purchasedSeatsMap.get(movie).containsKey(schedule)
                    && purchasedSeatsMap.get(movie).get(schedule).containsKey(day)
                    && purchasedSeatsMap.get(movie).get(schedule).get(day).contains(i + 1)) {
                seatButton.setBackground(Color.PINK); // Kursi dah dibeli (beda biar notice)
            } else {
                seatButton.setBackground(Color.GREEN); // Available
                seatButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int seatNumber = Integer.parseInt(seatButton.getText());
                        if (!selectedSeats.contains(seatNumber)) {
                            selectedSeats.add(seatNumber);
                            seatButton.setBackground(Color.RED); // dipilih
                        } else {
                            selectedSeats.remove((Integer) seatNumber);
                            seatButton.setBackground(Color.GREEN); // cancel
                        }
                        updateTotalPrice();
                    }
                });
                seatButton.setEnabled(true); 
            }
            seatSelectionPanel.add(seatButton);
        }
        // Tombol continue
        continueButton = new JButton("Continue");
        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //error message kalo ngga ada kursi dipilih tapi ttp lanjut
                if (selectedSeats.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please select at least one seat.");
                } else {
                    showPaymentPanel();
                }
            }
        });
        // munculin panel kursi sama tombol continue di panel kursi
        seatPanel.add(new JScrollPane(seatSelectionPanel), BorderLayout.CENTER);
        seatPanel.add(continueButton, BorderLayout.SOUTH);

        add(seatPanel, "SeatPanel");
        revalidate();
        repaint();
        // tombol retunr di panel kursi
        JButton returnButton = new JButton("Return to Movie Selection");
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showMoviePanel(); // target return
            }
        });
        
        seatPanel.add(returnButton, BorderLayout.NORTH); // tombol return ke panel movie di bagian atas seatpanel
    }
    // generate daftar kursi yang udah diisi scra random
    private List<Integer> generateOccupiedSeats() {
        Random random = new Random();
        List<Integer> occupiedSeats = new ArrayList<>();
        int numOccupiedSeats = random.nextInt(TOTAL_SEATS / 2); // isi setengah dari total kursi dengan  random
        for (int i = 0; i < numOccupiedSeats; i++) {
            int seat = random.nextInt(TOTAL_SEATS) + 1; // Menghasilkan nomor kursi secara random (utk logic)
            if (!occupiedSeats.contains(seat)) {
                occupiedSeats.add(seat);
            }
        }
        return occupiedSeats;
    }

    // pembayaran
    private void initializePaymentPanel() {
        paymentPanel = new JPanel();
        paymentPanel.setLayout(new GridLayout(4, 1));

        totalLabel = new JLabel("Total Price: Rp 0");
        paymentOptionComboBox = new JComboBox<>(new String[]{"E-Wallet", "Debit", "Credit"});
        payButton = new JButton("Pay");
        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String paymentOption = (String) paymentOptionComboBox.getSelectedItem();
                processPayment(paymentOption);
            }
        });

        paymentPanel.add(totalLabel);
        paymentPanel.add(paymentOptionComboBox);
        paymentPanel.add(payButton);
    // Tombol return ke panel pemilihan kursi
    JButton returnButton = new JButton("Return to Seat Selection");
    returnButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            showSeatPanel();
        }
    });
    
    paymentPanel.add(returnButton, BorderLayout.NORTH); // tombol retunr ke panel seat selection di bagian atas payment tpanel
    }

    private void processPayment(String paymentOption) {
        // terapin logika pemrosesan pembayaran di sini
        // biar simpel, di cetak aja detail tiketnya
        String movie = (String) movieComboBox.getSelectedItem();
        String schedule = (String) scheduleComboBox.getSelectedItem();
        String day = (String) dayComboBox.getSelectedItem();
        int totalPrice = selectedSeats.size() * TICKET_PRICE;
    
        // Generate booking ID
        int bookingId = bookingIdCounter++;
    
        // print detail tiket tanpa ID pemesanan (tiket belum dibayar)
        StringBuilder ticketDetails = new StringBuilder();
        ticketDetails.append("Movie: ").append(movie).append("\n");
        ticketDetails.append("Schedule: ").append(schedule).append("\n");
        ticketDetails.append("Date: ").append(day).append("\n");
        ticketDetails.append("Seats: ");
        for (int seat : selectedSeats) {
            ticketDetails.append(seat).append(", ");
        }
        ticketDetails.delete(ticketDetails.length() - 2, ticketDetails.length()); 
        ticketDetails.append("\n");
        ticketDetails.append("Total Price: Rp ").append(totalPrice).append("\n");
        ticketDetails.append("Payment Option: ").append(paymentOption);
        // nampilin detail tiket sama pesan konfirmasi pembayaran (belum dibayar)
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the payment?\n\n" + ticketDetails.toString(), "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // print detail tiket sama ID pemesanan (tiket udah di bayar)
            StringBuilder ticketWithBookingId = new StringBuilder(ticketDetails);
            ticketWithBookingId.insert(0, "Booking ID: " + bookingId + "\n\n");
            ticketWithBookingId.insert(0, "Ticket Details:\n");
    
            JOptionPane.showMessageDialog(null, "Payment processed successfully!\n\n" + ticketWithBookingId.toString());
    
            // Tandain kursi yang dipilih sebagai kursi yang udah dibeli
            markSelectedSeatsAsPurchased(movie, schedule, day);
    
            // update UI
            selectedSeats.clear();
            updateTotalPrice();
            showMoviePanel();
        }
    }    
    // nandain kursi yang dipilih dan udah lewat proses payment sebagai kursi yang sudah dibeli (biar ga clash)
    private void markSelectedSeatsAsPurchased(String movie, String schedule, String day) {
        if (!purchasedSeatsMap.containsKey(movie)) {
            purchasedSeatsMap.put(movie, new HashMap<>());
        }
        if (!purchasedSeatsMap.get(movie).containsKey(schedule)) {
            purchasedSeatsMap.get(movie).put(schedule, new HashMap<>());
        }
        if (!purchasedSeatsMap.get(movie).get(schedule).containsKey(day)) {
            purchasedSeatsMap.get(movie).get(schedule).put(day, new ArrayList<>());
        }
        purchasedSeatsMap.get(movie).get(schedule).get(day).addAll(selectedSeats);
    }
    // update total harga tiket
    private void updateTotalPrice() {
        int totalPrice = selectedSeats.size() * TICKET_PRICE;
        totalLabel.setText("Total Price: Rp " + totalPrice);
    }
    // munculin panel pemilihan film
    private void showMoviePanel() {
        CardLayout cardLayout = (CardLayout) getContentPane().getLayout();
        cardLayout.show(getContentPane(), "MoviePanel");
    }
    // munculin panel seat selection
    private void showSeatPanel() {
        CardLayout cardLayout = (CardLayout) getContentPane().getLayout();
        cardLayout.show(getContentPane(), "SeatPanel");
    }
    // munculin panel payment
    private void showPaymentPanel() {
        CardLayout cardLayout = (CardLayout) getContentPane().getLayout();
        cardLayout.show(getContentPane(), "PaymentPanel");
    }
    // main function, do not disturb
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Cinema().setVisible(true);
            }
        });
    }
}


